package com.ultrafps.mixin;

import com.ultrafps.Engine;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public abstract class MinecraftMixin {
    @Inject(method = "runTick", at = @At("HEAD"))
    private void ultrafps$onFrame(boolean renderLevel, CallbackInfo ci) {
        Engine.INSTANCE.onFrame((Minecraft) (Object) this);
    }
}
