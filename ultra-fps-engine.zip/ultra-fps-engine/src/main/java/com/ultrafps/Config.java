package com.ultrafps;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Optional config. Created automatically; the user never has to touch it. */
public class Config {
    public int renderDistance = 32;
    public boolean lockRenderDistance = true;
    public boolean lockClouds = true;
    public boolean adaptive = true;          // step settings down only if FPS stays under target
    public int targetFps = 20;
    public boolean allowFastGraphics = true; // only used as the last adaptive step, never with shaders

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static Config load() {
        Path p = FabricLoader.getInstance().getConfigDir().resolve("ultra_fps_engine.json");
        try {
            if (Files.exists(p)) {
                Config c = GSON.fromJson(Files.readString(p), Config.class);
                if (c != null) return c;
            }
            Config c = new Config();
            Files.writeString(p, GSON.toJson(c));
            return c;
        } catch (Throwable t) {
            return new Config();
        }
    }
}
