package com.ultrafps;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.GraphicsStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;
import net.minecraft.client.ParticleStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;

/**
 * Applies real, supported vanilla option changes. Never touches FPS counters,
 * sun, moon, clouds, terrain or render distance (kept at 32).
 * Runs on the render thread, does tiny work every frame and real work only every few seconds.
 */
public final class Engine {
    public static final Engine INSTANCE = new Engine();
    private static final Logger LOG = LoggerFactory.getLogger("UltraFpsEngine");

    private Config cfg = new Config();
    private boolean disabled;
    private int errors;
    private boolean baseApplied;
    private int tier;                 // 0 base, 1 reduced, 2 maximum
    private long frames;
    private long lastNs;
    private double avgMs;
    private int simSnapshot = -1;
    private CloudStatus cloudSnapshot;

    private boolean hasIris, hasSodium;

    public void init() {
        cfg = Config.load();
        FabricLoader fl = FabricLoader.getInstance();
        hasIris = fl.isModLoaded("iris");
        hasSodium = fl.isModLoaded("sodium");
        LOG.info("ULTRA FPS ENGINE started. Iris={} Sodium={} Lithium={} FerriteCore={} EntityCulling={} ImmediatelyFast={}",
                hasIris, hasSodium, fl.isModLoaded("lithium"), fl.isModLoaded("ferritecore"),
                fl.isModLoaded("entityculling"), fl.isModLoaded("immediatelyfast"));
    }

    public void onFrame(Minecraft mc) {
        if (disabled || mc.options == null) return;
        try {
            tick(mc);
        } catch (Throwable t) {
            if (++errors >= 3) {
                disabled = true;
                LOG.error("ULTRA FPS ENGINE disabled itself after repeated errors", t);
            }
        }
    }

    private void tick(Minecraft mc) {
        frames++;
        long now = System.nanoTime();
        if (mc.level == null || mc.getOverlay() != null) { lastNs = 0; }
        else {
            if (lastNs != 0) {
                double ms = (now - lastNs) / 1_000_000.0;
                avgMs = avgMs == 0 ? ms : avgMs * 0.98 + ms * 0.02;
            }
            lastNs = now;
        }

        if (!baseApplied) {
            if (mc.getOverlay() != null) return;   // wait until loading is finished
            simSnapshot = mc.options.simulationDistance().get();
            cloudSnapshot = mc.options.cloudStatus().get();
            apply(mc);
            baseApplied = true;
            return;
        }
        if (frames % 120 == 0) guard(mc);
        if (cfg.adaptive && frames % 900 == 0 && mc.level != null && avgMs > 0) {
            double fps = 1000.0 / avgMs;
            if (fps < cfg.targetFps && tier < 2) {
                tier++;
                LOG.info("Average FPS {} below target {}, moving to tier {}", (int) fps, cfg.targetFps, tier);
                apply(mc);
                avgMs = 0;
            }
        }
    }

    private static <T> boolean put(OptionInstance<T> o, T v) {
        if (Objects.equals(o.get(), v)) return false;
        o.set(v);
        return true;
    }

    private void apply(Minecraft mc) {
        Options o = mc.options;
        boolean shader = shaderActive();
        boolean changed = false;

        // Tier 0: always safe, visually minor
        changed |= put(o.ambientOcclusion(), false);
        changed |= put(o.entityShadows(), false);
        changed |= put(o.enableVsync(), false);
        changed |= put(o.biomeBlendRadius(), Math.min(o.biomeBlendRadius().get(), 1));
        if (o.graphicsMode().get() == GraphicsStatus.FABULOUS) {
            changed |= put(o.graphicsMode(), GraphicsStatus.FANCY);
        }
        if (o.particles().get() == ParticleStatus.ALL) {
            changed |= put(o.particles(), ParticleStatus.DECREASED);
        }

        // Tier 1: more savings if FPS stays under target
        if (tier >= 1) {
            changed |= put(o.particles(), ParticleStatus.MINIMAL);
            changed |= put(o.entityDistanceScaling(), Math.min(o.entityDistanceScaling().get(), 0.6));
        }
        // Tier 2: last step. Never with shaders (Iris overrides it anyway).
        if (tier >= 2 && cfg.allowFastGraphics && !shader) {
            changed |= put(o.graphicsMode(), GraphicsStatus.FAST);
        }

        changed |= guard(mc);
        if (changed) o.save();
    }

    /** Re-asserts protected settings. Returns true if something was restored. */
    private boolean guard(Minecraft mc) {
        Options o = mc.options;
        boolean changed = false;
        if (cfg.lockRenderDistance) changed |= put(o.renderDistance(), cfg.renderDistance);
        if (simSnapshot > 0 && o.simulationDistance().get() < simSnapshot) {
            changed |= put(o.simulationDistance(), simSnapshot);
        }
        if (cfg.lockClouds && cloudSnapshot != null && cloudSnapshot != CloudStatus.OFF
                && o.cloudStatus().get() == CloudStatus.OFF) {
            changed |= put(o.cloudStatus(), cloudSnapshot);
        }
        if (changed && frames % 120 == 0) mc.options.save();
        return changed;
    }

    /** Iris API via reflection (Iris classes are not obfuscated), safe if Iris is missing. */
    private boolean shaderActive() {
        if (!hasIris) return false;
        try {
            Class<?> c = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
            Object api = c.getMethod("getInstance").invoke(null);
            return (boolean) c.getMethod("isShaderPackInUse").invoke(api);
        } catch (Throwable t) {
            return false;
        }
    }
}
