package com.ultrafps;

import net.fabricmc.api.ClientModInitializer;

public class UltraFpsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        Engine.INSTANCE.init();
    }
}
