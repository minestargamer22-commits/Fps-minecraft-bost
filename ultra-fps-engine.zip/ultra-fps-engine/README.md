# ULTRA FPS ENGINE (Fabric, Minecraft 1.21.11)

Client-only Fabric mod. Install the jar and launch. It changes real vanilla options only.
It does NOT fake FPS and does NOT touch sun, moon, clouds, terrain, render distance (locked to 32) or simulation distance.

## What it does
- Tier 0 (once, after loading): AO off, entity shadows off, vsync off, biome blend <=1, Fabulous->Fancy, particles All->Decreased
- Tier 1 (only if avg FPS stays under 20): particles Minimal, entity distance 0.6
- Tier 2 (only if still under 20, no shaders): Fast graphics
- Every ~6 s re-locks render distance 32, simulation distance, clouds
- Detects Iris/Sodium/Lithium/etc. in the log. Does not edit shader packs or other mods' configs.
- Config: config/ultra_fps_engine.json (optional)

## Not possible from a mod
Memory/GC tuning needs JVM args in PojavLauncher, e.g. `-XX:+UseSerialGC -Xmx1500M` (adjust to your RAM).

## Build
Upload the contents of this folder to the GitHub repo ROOT (build.gradle must be in the root), push, open Actions, download the artifact jar.
Local: `gradle build` with Java 21, jar in build/libs/.

## Untested
Written without a build environment. If Actions fails, send the error log.
